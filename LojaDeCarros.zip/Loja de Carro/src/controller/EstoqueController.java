/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import dao.Conexao;
import dao.daoEstoque;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import static java.util.Objects.toString;
import static java.util.Objects.toString;
import javax.swing.JOptionPane;
import static jdk.nashorn.internal.objects.NativeString.toLowerCase;
import model.Estoque;
import model.Fabricante;
import view.CadastroEstoque;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class EstoqueController {
    
    public boolean cadastrarEstoque(String id, String valorDeCompra, String cor, String placa, String valorDeVenda, String ar, String rodaDeLigaLeve
    , String bancoEmCoro, String multimidia, String pinturaPerolada, String marca, String modelo){
        
        
    
        
        
       
        
        if(valorDeCompra != null && valorDeCompra.length() > 0 && cor != null && cor.length() > 0 && placa != null && placa.length() > 0 &&
                valorDeVenda != null && valorDeVenda.length() > 0 && rodaDeLigaLeve != null && rodaDeLigaLeve.length() > 0 && ar != null && ar.length() > 0 &&
                bancoEmCoro != null && bancoEmCoro.length() > 0 && multimidia != null && multimidia.length() > 0 && pinturaPerolada != null && 
                pinturaPerolada.length() > 0 && modelo != null && modelo.length() > 0 && marca != null && marca.length() > 0 ){
                
                //instanciando as model estoque e fabricante
                Estoque estoque = new Estoque();
                Fabricante fabricante = new Fabricante();
              
               //convertendo em float as strings
               Float valorDeCompraC = Float.parseFloat(valorDeCompra);
               Float valorDeVendaC = Float.parseFloat(valorDeVenda);
               
               //inserindo os valores em estoque
               estoque.setValorDeCompra(valorDeCompraC);
               estoque.setCor(cor);
               estoque.setPlaca(placa);
               estoque.setValorDeVenda(valorDeVendaC);
               estoque.setRodasDeLigaLeve(rodaDeLigaLeve);
               estoque.setAr(ar);
               estoque.setBancoEmCoro(bancoEmCoro);
               estoque.setMultimidia(multimidia);
               estoque.setPinturaPerolada(pinturaPerolada);
               
               //inserindo valores em fabricante 
               fabricante.setMarca(marca);
               fabricante.setModelo(modelo);
               
               
               
               
               
               /* como o id no banco é auto-increment então coloquei essa verificação, pois não é 
                 necessario o usuario digitar o id, pois ele vai de forma altomatica, provavelmente o 
                 campo id vai ficar em desativado.
               */
               if (id != null && id.length() > 0){
                    Integer idC = Integer.parseInt(id);
                    
               }
               
               dao.daoEstoque es = new daoEstoque();
               
               es.inserirEstoque(estoque, fabricante);
               
               view.CadastroEstoque ce = new CadastroEstoque();
               ce.limparTela();
            
            return true;
                
            
        }else{
            
            JOptionPane.showMessageDialog(null, "Preencha os campos corretamente!");
        }
        
        
        return false;
        
        
    }

   
    
    
    public void cadastrarEstoqueB() throws SQLException{
        CadastroEstoque ce = new CadastroEstoque();
    
        Connection c = new Conexao().getConnection();
        
         String estoque = "insert into estoque " + "(valorDeCompra, cor, placa, valorDeVenda, rodasDeLogaLeve,"
                + "bancoEmCoro, multimidia, pinturaPerolada) " + "values (?,?,?,?,?,?,?,?)";
        
        
        PreparedStatement stm = c.prepareStatement(estoque);
        
       // stm.setFloat(1, ce.);
        
        //inserir dados no estoque
           
        
    }

       
   
    

  
    

}
    
    