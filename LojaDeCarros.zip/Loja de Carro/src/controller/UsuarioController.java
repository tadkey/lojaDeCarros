/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import dao.daoUsuario;
import javax.swing.JOptionPane;
import model.Cliente;
import model.Usuario;
import view.CadastroUsuario;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class UsuarioController {
        
        //Criar metodo para receber os dados da Tela Cadastro Usuario
        public boolean cadastrarUsuario(String nome, String cpf, String telefone, String matricula, 
                String cargo, String email){
        
        
    
        
        
       
        //Validando dados de Cadastro Usuario se não for nulo entra no if
        if(nome != null && nome.length() > 0 && cpf != null && cpf.length() > 0 && 
                telefone != null && telefone.length() > 0 && matricula != null && matricula.length() > 0 &&
                email != null && email.length() > 0){
            
            //depois de saber se matricula e id não é nulo os dois campo é convertido para inteiro
            int matriculaConvertido = Integer.parseInt(matricula);
           
            
            //instanciando cliente e passando dados como parametros
            Usuario us = new Usuario();
            
            us.setNome(nome);
            us.setCpf(cpf);
            us.setTelefone(telefone);
            us.setMatricula(matriculaConvertido);
            us.setEmail(email);
            
            
            if(cargo != null && cargo.length() > 0){
                us.setCargo(cargo);
            }
            
            daoUsuario daoUser = new daoUsuario();
            
            daoUser.cadastrarUsuarioNoBanco(us);
            CadastroUsuario cut = new CadastroUsuario();
            cut.limparTela();
            
            return true;
                
            
        }
        
        JOptionPane.showMessageDialog(null, "Digite os campos!");
        return false;
        
        
    }
    
        
        

    
    
}
