/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import dao.daoLogin;
import javax.swing.JOptionPane;
import model.Login;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class LoginController {
    
    public boolean realizarLogin(String usuario, String senha){
            
        if(usuario != null && usuario.length() > 0){
            if(senha != null && senha.length() > 0){
               Login login = new Login();
               login.setUsuario(usuario);
               login.setSenha(senha);
               
               daoLogin dao = new daoLogin();
               dao.verificarLogin(login);
               
               
                return true;
            }
            JOptionPane.showMessageDialog(null, "Digitar a senha!");
            return false;
        }
        JOptionPane.showMessageDialog(null, "Digite o Usuario e Senha!");
        return false;
        
    }
    
    public void validarLogin(Login login, Login login1){
        
        if (login.getUsuario().equals(login1.getUsuario()) && login.getSenha().equals(login1.getSenha())){
            JOptionPane.showMessageDialog(null, "Seja bem vindo " + login.getUsuario());
            new view.Index().setVisible(true);
        }else{
            JOptionPane.showMessageDialog(null, "Usuario Incorreto!");
        }
    }
}
