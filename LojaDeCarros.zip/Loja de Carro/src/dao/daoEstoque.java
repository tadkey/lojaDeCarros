/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Estoque;
import model.Fabricante;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class daoEstoque {
    

    public void inserirEstoque(Estoque estoque, Fabricante fabricante){
         
              try(Connection conect = new Conexao().getConnection()){
                      
                String sqlF = "SELECT id FROM fabricante WHERE marca LIKE '%"+fabricante.getMarca().toLowerCase()+"%' AND modelo LIKE '%"+fabricante.getModelo().toLowerCase()+"%'";
                PreparedStatement stm = conect.prepareStatement(sqlF);
                    ResultSet rs = stm.executeQuery();
                     while(rs.next()){
                    fabricante.setId(rs.getInt("id"));
                    
                }
                    rs.close();
                    stm.close();
             
                   
           
                   String inserir = "INSERT INTO estoque (valorDeCompra, cor, placa, valorDeVenda, rodasDeLogaLeve,"
                           + "bancoEmCoro, multimidia, pinturaPerolada, codFabricante)" + " VALUES (?,?,?,?,?,?,?,?,?)";
            
                   PreparedStatement stmE = conect.prepareStatement(inserir);
                   
                   stmE.setFloat(1,estoque.getValorDeCompra());
                   stmE.setString(2, estoque.getCor().toLowerCase());
                   stmE.setString(3, estoque.getPlaca().toLowerCase());
                   stmE.setFloat(4, estoque.getValorDeVenda());
                   stmE.setString(5, estoque.getRodasDeLigaLeve().toLowerCase());
                   stmE.setString(6, estoque.getBancoEmCoro().toLowerCase());
                   stmE.setString(7, estoque.getMultimidia().toLowerCase());
                   stmE.setString(8, estoque.getPinturaPerolada().toLowerCase());
                   stmE.setInt(9, fabricante.getId());
                   
                   stmE.execute();
                   
                   JOptionPane.showMessageDialog(null, "Cadastro efetuado com Sucesso!");
                   
                   
                   
                   
              }catch(SQLException ec){
                   throw new RuntimeException(ec);
               }

     }
    
    
}
