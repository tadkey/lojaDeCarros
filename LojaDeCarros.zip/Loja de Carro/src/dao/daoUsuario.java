/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import model.Usuario;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class daoUsuario {
    public void cadastrarUsuarioNoBanco(Usuario usuario){
        try(Connection conect = new Conexao().getConnection()){
            String sql = "INSERT INTO usuario" + "(cpf, email, nome, matricula, cargo)" + " VALUES(?,?,?,?,?)";
            
            PreparedStatement stmt = conect.prepareStatement(sql);
            stmt.setString(1, usuario.getCpf().toLowerCase());
            stmt.setString(2, usuario.getEmail().toLowerCase());
            stmt.setString(3, usuario.getNome().toLowerCase());
            stmt.setInt(4, usuario.getMatricula());
            stmt.setString(5, usuario.getCargo().toLowerCase());
            
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!");
            stmt.close();
            
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Erro ao Inserir Usuario no Banco! Erro: " + e);
        }
    }
}
