/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class Conexao {
    public java.sql.Connection getConnection() {
        try {
            return DriverManager.getConnection("jdbc:mysql://localhost/sigcar","root", "");
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
    }
}
