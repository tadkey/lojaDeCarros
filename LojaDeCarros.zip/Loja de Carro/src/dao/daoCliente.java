/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Cliente;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class daoCliente {
    
    public void inserirCliente(Cliente cliente){
        
        try(Connection conect = new Conexao().getConnection()){
            String sql = "INSERT INTO cliente (cpf, dataDeNascimento, nomeCompleto, cnh, nivelEscolar, estadoCivil, rg, rua, cep,"
                    + "cidade, numero, complemento )" + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
            
            PreparedStatement stm = conect.prepareStatement(sql);
            
            stm.setString(1,  cliente.getCpf());
            stm.setString(2, cliente.getDataDeNascimento());
            stm.setString(3, cliente.getNomeCompleto());
            stm.setString(4, cliente.getCnh());
            stm.setString(5, cliente.getNivelEscolar());
            stm.setString(6, cliente.getEstadoCivil());
            stm.setString(7, cliente.getRg());
            stm.setString(8, cliente.getRua());
            stm.setString(9, cliente.getCep());
            stm.setString(10, cliente.getCidade());
            stm.setInt(11, cliente.getNumero());
            stm.setString(12, cliente.getComplemento());
            stm.execute();
            stm.close();
            
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
        
    }
}
