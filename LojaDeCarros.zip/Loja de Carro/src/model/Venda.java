/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;
import java.util.ArrayList;
import java.util.Date;
/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class Venda {
    private Integer id; private Date dataDaVenda; private Integer codigoVenda;
    private ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
    private Cliente client; private ArrayList<Estoque> estoque = new ArrayList<Estoque>();
    
    
}
