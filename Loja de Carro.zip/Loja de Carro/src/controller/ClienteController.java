/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import dao.daoCliente;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import model.Cliente;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class ClienteController {
    
     public void cadastrarCliente(Cliente  cliente ) throws ParseException{
            
       /*  if(cpf != null && cpf.length() > 0 && dataNascimento != null && dataNascimento.length() > 0 && nomeCompleto != null && nomeCompleto.length() > 0 && cnh != null && cnh.length() > 0 &&
                 nivelEscolar != null && nivelEscolar.length() > 0 && estadoCivil != null && estadoCivil.length() > 0 && rg != null && rg.length() > 0 &&
                 rua != null && rua.length() > 0 && cep != null && cep.length() > 0 && numero != null && numero.length() > 0 && cidade != null && cidade.length() > 0 ){
             
             Integer numeroConvertido = Integer.parseInt(numero);
             
             //converter data para formato americano
             String dia = dataNascimento.substring(0, 2);
             String mes = dataNascimento.substring(3,5);
             String ano = dataNascimento.substring(6);
             
             
             String dataParaMySQL = ano+"-"+mes+"-"+dia;
             
             //instanciando cliente
             model.Cliente cliente = new Cliente();
             
             //inserindo dados no objeto
             cliente.setCpf(cpf);
             cliente.setDataDeNascimento(dataParaMySQL);
             cliente.setNomeCompleto(nomeCompleto);
             cliente.setCnh(cnh);
             cliente.setNivelEscolar(nivelEscolar);
             cliente.setEstadoCivil(estadoCivil);
             cliente.setRg(rg);
             cliente.setRua(rua);
             cliente.setCep(cep);
             cliente.setNumero(numeroConvertido);
             cliente.setCidade(cidade);
             if(complemento != null && complemento.length() > 0){
                 cliente.setComplemento(complemento);
             }*/
             
             dao.daoCliente dao = new daoCliente();
             dao.inserirCliente(cliente);
             
             JOptionPane.showMessageDialog(null, "Cadastro feito!");
             
            /* DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy"); 
             LocalDate data = LocalDate.parse(dataNascimento, formato); */
             
             //SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
             //Date dataFormatada = formato.parse(dataNascimento);
         
     }
     
     public void pesquisarCliente(Cliente cliente){
         ArrayList<Cliente>  clientes = new ArrayList<Cliente>();
         daoCliente dao = new daoCliente();
         clientes = dao.consultarCliente(cliente);
         
       
     }
     public Boolean retorno(Boolean valor){
         
         
         return valor;
     }
     
     public void excluirCliente(Cliente cliente){
         daoCliente dao = new daoCliente();
         dao.excluirCliente(cliente);
     }
 
     
     
     
    

}
