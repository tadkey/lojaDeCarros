/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import model.Estoque;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class EstoqueController {
    
    public boolean cadastrarEstoque(Integer id, Float valorDeCompra, String cor, String placa, Float valorDeVenda, String rodaDeLigaLeve, String ar
    , String bancoEmCoro, String multimidia, String pinturaPerolada){
        
        if(id != null && id > 0 && valorDeCompra != null && valorDeCompra > 0 && cor != null && cor.length() > 0 && placa != null && placa.length() > 0 &&
                valorDeVenda != null && valorDeVenda > 0 && rodaDeLigaLeve != null && rodaDeLigaLeve.length() > 0 && ar != null && ar.length() > 0 &&
                bancoEmCoro != null && bancoEmCoro.length() > 0 && multimidia != null && multimidia.length() > 0 && pinturaPerolada != null && 
                pinturaPerolada.length() > 0){
            
            Estoque estoque = new Estoque(id, valorDeCompra, cor, placa, valorDeVenda, rodaDeLigaLeve, ar, bancoEmCoro, multimidia, pinturaPerolada);
            estoque.cadastrarEstoque(estoque);
            return true;
                
            
        }
        
        
        return false;
        
        
    }
}
