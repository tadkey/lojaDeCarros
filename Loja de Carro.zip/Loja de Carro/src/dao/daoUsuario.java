/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import model.Login;
import model.Usuario;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class daoUsuario {
    public void cadastrarUsuarioNoBanco(Usuario usuario){
        try(Connection conect = new Conexao().getConnection()){
            
            //INSERIRNDO NA TABELA USUARIO
            String sql = "INSERT INTO usuario" + "(cpf, email, nome, matricula, cargo)" + " VALUES(?,?,?,?,?)";
            
            
            PreparedStatement stmt = conect.prepareStatement(sql);
            stmt.setString(1, usuario.getCpf().toLowerCase());
            stmt.setString(2, usuario.getEmail().toLowerCase());
            stmt.setString(3, usuario.getNome().toLowerCase());
            stmt.setInt(4, usuario.getMatricula());
            stmt.setString(5, usuario.getCargo().toLowerCase());
            
            stmt.execute();
            
            //PEGONDO ID DE USUARIO                
            String sql1 = "SELECT id FROM usuario WHERE cpf LIKE '%"+usuario.getCpf()+"%'";
            stmt = conect.prepareCall(sql1);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                usuario.setId(rs.getInt("id"));
            }
            rs.close();
            
            //INSERINDO USUARIO NA TABELA LOGIN
            String login1 = "INSERT INTO login" +  "(usuario, senha, codUsuario)" + " VALUES(?,?,?)";
            stmt = conect.prepareStatement(login1);
            
            stmt.setString(1, usuario.getLogin().getUsuario());
            stmt.setString(2, usuario.getLogin().getSenha());
            stmt.setInt(3, usuario.getId());
            stmt.execute();
            //Mensagem de confirmação
            JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!");
            
            //fechando o PreparedStatement
            stmt.close();
            
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Erro ao Inserir Usuario no Banco! Erro: " + e);
        }
    }
    
    public void cadastrarLogin(Usuario usuario ,Login login){
        
        
    }
}
