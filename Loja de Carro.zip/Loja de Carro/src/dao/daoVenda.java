/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;
import javax.swing.JOptionPane;
import model.Cliente;
import model.Estoque;
import model.Usuario;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class daoVenda {
    
    public void vender(Cliente cliente){
        
        
        
        
        
        try(Connection conn = new Conexao().getConnection()){
        
            
            
        String sql = "INSERT INTO venda (dataDaVenda, codCliente) VALUES (?,?)";
        PreparedStatement stmt = conn.prepareStatement(sql);
        java.sql.Date dataParaGravar = new java.sql.Date(Calendar.getInstance().getTimeInMillis());
        stmt.setDate(1, dataParaGravar);
        stmt.setInt(2, cliente.getId());
        
        stmt.execute();
        
        
        
        }catch(SQLException e){
            throw new RuntimeException (e);
        }
        
        JOptionPane.showMessageDialog(null, "Venda Realizada com Sucesso");
    }
}
