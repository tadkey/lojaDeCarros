/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import jdk.nashorn.internal.scripts.JO;
import model.Cliente;
import model.HistoricoDeCompras;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class daoCliente {
    
    public void inserirCliente(Cliente cliente){
        
        try(Connection conect = new Conexao().getConnection()){
            String sql = "INSERT INTO cliente (cpf, dataDeNascimento, nomeCompleto, cnh, nivelEscolar, estadoCivil, rg, rua, cep,"
                    + "cidade, numero, complemento )" + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
            
            PreparedStatement stm = conect.prepareStatement(sql);
            
            stm.setString(1,  cliente.getCpf().toLowerCase());
            stm.setString(2, cliente.getDataDeNascimento().toLowerCase());
            stm.setString(3, cliente.getNomeCompleto().toLowerCase());
            stm.setString(4, cliente.getCnh().toLowerCase());
            stm.setString(5, cliente.getNivelEscolar().toLowerCase());
            stm.setString(6, cliente.getEstadoCivil().toLowerCase());
            stm.setString(7, cliente.getRg().toLowerCase());
            stm.setString(8, cliente.getRua().toLowerCase());
            stm.setString(9, cliente.getCep().toLowerCase());
            stm.setString(10, cliente.getCidade().toLowerCase());
            stm.setInt(11, cliente.getNumero());
            stm.setString(12, cliente.getComplemento().toLowerCase());
            stm.execute();
            stm.close();
            
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
        
    }
    
    public ArrayList<Cliente> consultarCliente(Cliente cliente){
        ArrayList<Cliente> lista = new ArrayList<Cliente>();
        
        try(Connection conexao = new Conexao().getConnection()){
        String sql = "SELECT id,cpf, nomeCompleto, cnh,nivelEscolar, estadoCivil FROM cliente WHERE cpf LIKE"
                + " '%"+ cliente.getCpf() +"%' AND nomeCompleto LIKE '%"+cliente.getNomeCompleto()+"%'";
        
        PreparedStatement stmt = conexao.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();
        
        while(rs.next()){
            Cliente cliente1 = new Cliente();
            cliente1.setId(rs.getInt("id"));
            cliente1.setCpf(rs.getString("cpf"));
            cliente1.setNomeCompleto(rs.getString("nomeCompleto"));
            cliente1.setCnh(rs.getString("cnh"));
            cliente1.setNivelEscolar(rs.getString("nivelEscolar"));
            cliente1.setEstadoCivil(rs.getString("estadoCivil"));
            
            lista.add(cliente1);
            
        }
        
        
                
                
        }catch (SQLException e ){
            
            throw new RuntimeException(e);
        }
        
       if (lista == null){
            JOptionPane.showMessageDialog(null, "Digite um CPF ou Nome válido!");
       }
        
     return lista;
    }
    
    
    public void excluirCliente(Cliente cliente){
        
        try(Connection con = new Conexao().getConnection()){
              String sql = "DELETE FROM historicodecompras WHERE codCliente ='"+cliente.getId()+"'";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.executeUpdate();
            
           /* String sql1 = "DELETE FROM venda WHERE codCliente ='"+cliente.getId()+"'";
            stmt = con.prepareStatement(sql1);
            stmt.executeUpdate();*/
            
            String sql2 = "DELETE FROM cliente WHERE id ='"+cliente.getId()+"' AND cpf ='"+cliente.getCpf()+"'";
            stmt = con.prepareStatement(sql2);
            stmt.executeUpdate();
            
            
        }catch(SQLException e){
            
            throw new RuntimeException (e);
        }
        
        
      
    }
    
    public void alterarCliente(Cliente cliente1, Cliente cliente){
        
        try(Connection connn = new Conexao().getConnection()){
           
            String sql = "UPDATE cliente SET nomeCompleto = '"+cliente.getNomeCompleto()+"' , cnh = '"+cliente.getCnh()+"' , estadoCivil = '"+cliente.getEstadoCivil()+"'"
                    + " WHERE nomeCompleto = '"+cliente1.getNomeCompleto()+"' AND cnh = '"+cliente1.getCnh()+"' ";
            
            PreparedStatement stmt = connn.prepareStatement(sql);
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Alteração Feita com Sucesso");

                       
        }catch(SQLException exe){
            throw new RuntimeException(exe);
        }
        
    }
    
    public ArrayList<Cliente> relatorio3(){
        ArrayList<Cliente> cliente = new ArrayList<Cliente>();
        
        try(Connection conn = new Conexao().getConnection()){
            String sql = "SELECT nomeCompleto , cnh, dataDeNascimento FROM cliente";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Cliente cliente1 = new Cliente();
                
                cliente1.setNomeCompleto(rs.getString("nomeCompleto"));
                cliente1.setCnh(rs.getString("cnh"));
                cliente1.setDataDeNascimento(rs.getString("dataDeNascimento"));
                
                cliente.add(cliente1);
            }
            
            
        }catch(SQLException ex){
            throw new RuntimeException (ex);
        }
        
        return cliente;
    }
    
    public ArrayList<HistoricoDeCompras> relatorio5(){
        ArrayList<HistoricoDeCompras> historico = new ArrayList<HistoricoDeCompras>();
        
        try(Connection cooo = new Conexao().getConnection()){
            
            String sql = "SELECT c.nomeCompleto , h.id, h.codCliente , h.quantidadeDeCarros, h.quantidadeDeAnaliseDeCredito, h.quantidadeDeCreditoNegado "
                    + "FROM cliente c RIGHT JOIN historicodecompras h ON c.id = h.codCliente WHERE c.nomeCompleto = 'José Barnabé da Silva'";
            PreparedStatement stmt = cooo.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Cliente cliente = new Cliente();
                HistoricoDeCompras hc = new HistoricoDeCompras();
                
                cliente.setNomeCompleto(rs.getString("c.nomeCompleto"));
                hc.setId(rs.getInt("h.id"));
                cliente.setId(rs.getInt("h.codCliente"));
                hc.setQuantidadeDeCarros(rs.getInt("h.quantidadeDeCarros"));
                hc.setQuantidadeDeAnaliseDeCreditos(rs.getInt("h.quantidadeDeAnaliseDeCredito"));
                hc.setQuantidadeDeCreditoNegado(rs.getInt("h.quantidadeDeCreditoNegado"));
                hc.setCliente(cliente);
                
                historico.add(hc);
                
            }
            
            
        }catch(SQLException exeh){
            throw new RuntimeException (exeh);
        }
        
        
        return historico;
    }
}
