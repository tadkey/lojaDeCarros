/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Estoque;
import model.Fabricante;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class daoEstoque {
    

    public void inserirEstoque(Estoque estoque){
         
              try(Connection conect = new Conexao().getConnection()){
                      
                String sqlF = "SELECT id FROM fabricante WHERE marca LIKE '%"+estoque.getFabricante().getMarca().toLowerCase()+"%' AND modelo LIKE '%"+estoque.getFabricante().getModelo().toLowerCase()+"%'";
                PreparedStatement stm = conect.prepareStatement(sqlF);
                    ResultSet rs = stm.executeQuery();
                     while(rs.next()){
                    estoque.getFabricante().setId(rs.getInt("id"));
                    
                }
                    rs.close();
                   
             
                   
           
                   String inserir = "INSERT INTO estoque (valorDeCompra, cor, placa, valorDeVenda, rodasDeLogaLeve,"
                           + "bancoEmCoro, multimidia, pinturaPerolada, codFabricante)" + " VALUES (?,?,?,?,?,?,?,?,?)";
            
                    stm = conect.prepareStatement(inserir);
                   
                   stm.setFloat(1,estoque.getValorDeCompra());
                   stm.setString(2, estoque.getCor().toLowerCase());
                   stm.setString(3, estoque.getPlaca().toLowerCase());
                   stm.setFloat(4, estoque.getValorDeVenda());
                   stm.setString(5, estoque.getRodasDeLigaLeve().toLowerCase());
                   stm.setString(6, estoque.getBancoEmCoro().toLowerCase());
                   stm.setString(7, estoque.getMultimidia().toLowerCase());
                   stm.setString(8, estoque.getPinturaPerolada().toLowerCase());
                   stm.setInt(9, estoque.getFabricante().getId());
                   
                   stm.execute();
                   
                   JOptionPane.showMessageDialog(null, "Cadastro efetuado com Sucesso!");
                   
                   stm.close();
                   
                   
              }catch(SQLException ec){
                   throw new RuntimeException(ec);
               }

     }
    
    public ArrayList<Estoque> setEstoque(Estoque estoque){
        
        ArrayList<Estoque> estoque1 = new ArrayList<Estoque>();
        
        try(Connection conn = new Conexao().getConnection()){
           
            /*if(estoque.getId() != null && estoque.getId() > 0 && estoque.getFabricante().getMarca().equals("")){
                  sql = "SELECT e.id, f.marca , f.modelo, e.valorDeVenda, e.cor , e.placa , e.rodasDeLogaLeve, e.bancoEmCoro , e.multimidia , e.pinturaPerolada FROM estoque AS e JOIN " +
                        "fabricante AS f ON e.codFabricante = f.id  WHERE e.id = "+estoque.getId()+"" ;             
            }else if ((estoque.getId() == 0 || estoque.getId() == null) && estoque.getFabricante().getMarca() != null && estoque.getFabricante().getMarca().length() > 0){
                     sql = "SELECT e.id, f.marca , f.modelo, e.valorDeVenda, e.cor , e.placa , e.rodasDeLogaLeve, e.bancoEmCoro , e.multimidia , e.pinturaPerolada FROM estoque AS e JOIN " +
                        "fabricante AS f ON e.codFabricante = f.id  WHERE f.marca = '"+estoque.getFabricante().getMarca()+"'" ;       
            }else if(estoque.getId() != null && estoque.getId() > 0 && estoque.getFabricante().getMarca() != null && estoque.getFabricante().getMarca().length() > 0){*/
                     String sql = "SELECT e.id, f.marca , f.modelo, e.valorDeVenda, e.cor , e.placa , e.rodasDeLogaLeve, e.bancoEmCoro , e.multimidia , e.pinturaPerolada FROM estoque AS e JOIN " +
                      "fabricante AS f ON e.codFabricante = f.id  WHERE e.id = "+estoque.getId()+" AND f.marca = '"+estoque.getFabricante().getMarca()+"'" ; 
           /* }else{
                JOptionPane.showMessageDialog(null, "Não é possivel fazer consulta sem valores! Digite Algo!");
                
            }*/
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Estoque estoque2 = new Estoque();
                Fabricante f2 = new Fabricante();
                estoque2.setId(rs.getInt("id"));
                f2.setMarca(rs.getString("marca"));
                f2.setModelo(rs.getString("modelo"));
                estoque2.setFabricante(f2);
                estoque2.setValorDeVenda(rs.getFloat("valorDeVenda"));
                estoque2.setCor(rs.getString("cor"));
                estoque2.setPlaca(rs.getString("placa"));
                estoque2.setRodasDeLigaLeve(rs.getString("rodasDeLogaLeve"));
                estoque2.setBancoEmCoro(rs.getString("bancoEmCoro"));
                estoque2.setMultimidia(rs.getString("multimidia"));
                estoque2.setPinturaPerolada(rs.getString("pinturaPerolada"));
                
                estoque1.add(estoque2);   
                
                
                
            }
            
            
            
        }catch(SQLException ex){
            throw new RuntimeException (ex);
        }
        
        
        return estoque1;
    }
    
    public ArrayList<Fabricante> listarFabricantes(){
        ArrayList<Fabricante> fabri = new ArrayList<Fabricante>();
        
        try(Connection con = new Conexao().getConnection()){
            String sql = "SELECT DISTINCT marca FROM fabricante;";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()){
                Fabricante fabricante = new Fabricante();
                fabricante.setMarca(rs.getString("marca"));
                
                fabri.add(fabricante);
            }
            
        }catch(SQLException exx){
            throw new RuntimeException(exx);
        }
        
        return fabri;
    }
    
    public ArrayList<Fabricante> relatorio2(){
        ArrayList<Fabricante> fabricante = new ArrayList<Fabricante>();
        
        try(Connection coonexao = new Conexao().getConnection()){
            
            String sql = "SELECT DISTINCT f.modelo, count(e.codFabricante) FROM estoque e INNER JOIN fabricante f ON e.id = f.id GROUP BY modelo";
            PreparedStatement stmt = coonexao.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Fabricante fabricante1 = new Fabricante();
                fabricante1.setModelo(rs.getString("f.modelo"));
                fabricante1.setId(rs.getInt("count(e.codFabricante)"));
                fabricante.add(fabricante1);
            }
            
        }catch(SQLException e){
            throw new RuntimeException (e);
        }
        
        return fabricante;
    }
    
    public ArrayList<Estoque> ralatorio4(){
        ArrayList<Estoque> estoque1 = new ArrayList<Estoque>();
        
        try(Connection coo = new Conexao().getConnection()){
            
            String sql = "SELECT placa , cor, valorDeVenda FROM estoque";
            PreparedStatement stmt = coo.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Estoque estoque2 = new Estoque();
                
                estoque2.setPlaca(rs.getString("placa"));
                estoque2.setCor(rs.getString("cor"));
                estoque2.setValorDeVenda(rs.getFloat("valorDeVenda"));
                
                estoque1.add(estoque2);
            }
            
        }catch(SQLException exe){
            throw new RuntimeException (exe);
        }      
        
        return estoque1;     
       
    }
    
}
