/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

import controller.LoginController;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Login;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class daoLogin {
    
    public void verificarLogin(Login login){
        
        try(Connection connect = new Conexao().getConnection()){
            
            String sqlF = "SELECT usuario, senha FROM login WHERE usuario LIKE '%"+login.getUsuario()+"%' AND senha LIKE '%"+login.getSenha()+"%'";
            PreparedStatement stm = connect.prepareStatement(sqlF);
            ResultSet rs = stm.executeQuery();
            Login login1 = new Login();
            while(rs.next()){
                login1.setUsuario(rs.getString("usuario"));
                login1.setSenha(rs.getString("senha"));
            }
            
            LoginController lc = new LoginController();
            lc.validarLogin(login, login1);
            
        }catch(SQLException ex) {
            throw new RuntimeException(ex);
        }
        
    }
}
