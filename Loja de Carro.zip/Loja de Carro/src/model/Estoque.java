/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class Estoque {
    private Integer id;  private Float valorDeCompra;   private String cor;
    private String placa;   private Float valorDeVenda; private String rodasDeLigaLeve;
    private String ar; private String bancoEmCoro;  private String multimidia;
    private String pinturaPerolada; private Venda venda; private Fabricante fabricante;

    public Estoque(Integer id, Float valorDeCompra, String cor, String placa, Float valorDeVenda, String rodaDeLigaLeve, String ar, String bancoEmCoro, String multimidia, String pinturaPerolada) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Integer getId() {
        return id;
    }

    public Float getValorDeCompra() {
        return valorDeCompra;
    }

    public String getCor() {
        return cor;
    }

    public String getPlaca() {
        return placa;
    }

    public Float getValorDeVenda() {
        return valorDeVenda;
    }

    public String getRodasDeLigaLeve() {
        return rodasDeLigaLeve;
    }

    public String getAr() {
        return ar;
    }

    public String getBancoEmCoro() {
        return bancoEmCoro;
    }

    public String getMultimidia() {
        return multimidia;
    }

    public String getPinturaPerolada() {
        return pinturaPerolada;
    }

    public Venda getVenda() {
        return venda;
    }

    public Fabricante getFabricante() {
        return fabricante;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setValorDeCompra(Float valorDeCompra) {
        this.valorDeCompra = valorDeCompra;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public void setValorDeVenda(Float valorDeVenda) {
        this.valorDeVenda = valorDeVenda;
    }

    public void setRodasDeLigaLeve(String rodasDeLigaLeve) {
        this.rodasDeLigaLeve = rodasDeLigaLeve;
    }

    public void setAr(String ar) {
        this.ar = ar;
    }

    public void setBancoEmCoro(String bancoEmCoro) {
        this.bancoEmCoro = bancoEmCoro;
    }

    public void setMultimidia(String multimidia) {
        this.multimidia = multimidia;
    }

    public void setPinturaPerolada(String pinturaPerolada) {
        this.pinturaPerolada = pinturaPerolada;
    }

    public void setVenda(Venda venda) {
        this.venda = venda;
    }

    public void setFabricante(Fabricante fabricante) {
        this.fabricante = fabricante;
    }
    
    
    
    public void cadastrarEstoque(Estoque estoque){
        
    }
    
}
