/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;
import java.util.Date;
import java.util.ArrayList;
/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class Cliente {
    private Integer id; private String cpf; private String dataDeNascimento;
    private String nomeCompleto;    private String cnh; private String nivelEscolar;
    private String estadoCivil; private String rg;  private String rua; private String cep;
    private String cidade;  

       //Construtor quase completo 
    public Cliente(String cpf, String dataDeNascimento, String nomeCompleto, String cnh, String nivelEscolar, String estadoCivil, String rg, String rua, String cep, String cidade, Integer numero, String complemento) {
      
        this.cpf = cpf;
        this.dataDeNascimento = dataDeNascimento;
        this.nomeCompleto = nomeCompleto;
        this.cnh = cnh;
        this.nivelEscolar = nivelEscolar;
        this.estadoCivil = estadoCivil;
        this.rg = rg;
        this.rua = rua;
        this.cep = cep;
        this.cidade = cidade;
        this.numero = numero;
        this.complemento = complemento;
    }

    //Construtor simples
    public Cliente(){}
   

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }
    private Integer numero; private String complemento; 
    private ArrayList<Venda1> venda = new ArrayList<Venda1>();
    private ArrayList<HistoricoDeCompras> historicoDeCompras = new ArrayList<HistoricoDeCompras>();

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getDataDeNascimento() {
        return dataDeNascimento;
    }

    public void setDataDeNascimento(String dataDeNascimento) {
        this.dataDeNascimento = dataDeNascimento;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

    public String getCnh() {
        return cnh;
    }

    public void setCnh(String cnh) {
        this.cnh = cnh;
    }

    public String getNivelEscolar() {
        return nivelEscolar;
    }

    public void setNivelEscolar(String nivelEscolar) {
        this.nivelEscolar = nivelEscolar;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public ArrayList<Venda1> getVenda() {
        return venda;
    }

    public void setVenda(ArrayList<Venda1> venda) {
        this.venda = venda;
    }

    public ArrayList<HistoricoDeCompras> getHistoricoDeCompras() {
        return historicoDeCompras;
    }

    public void setHistoricoDeCompras(ArrayList<HistoricoDeCompras> historicoDeCompras) {
        this.historicoDeCompras = historicoDeCompras;
    }

    
    

   
    

}
