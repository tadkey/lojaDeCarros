/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;
import java.util.Date;
import java.util.ArrayList;
/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class Cliente {
    private Integer id; private String cpf; private Date dataDeNascimento;
    private String nomeCompleto;    private String cnh; private String nivelEscolar;
    private String estadoCivil; private String rg;  private String rua; private String cep;
    private Integer numero; private String complemento; 
    private ArrayList<Venda> venda = new ArrayList<Venda>();
    private ArrayList<HistoricoDeCompras> historicoDeCompras = new ArrayList<HistoricoDeCompras>();
    

}
