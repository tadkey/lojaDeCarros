/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;
import java.util.ArrayList;
/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class Fabricante {
    private Integer id;  String marca;  private String modelo;
    private ArrayList<Estoque> estoque = new ArrayList<Estoque>();

    public Integer getId() {
        return id;
    }

     public void setId(Integer id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public ArrayList<Estoque> getEstoque() {
        return estoque;
    }

    public void setEstoque(ArrayList<Estoque> estoque) {
        this.estoque = estoque;
    }
    
       public Fabricante(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
 }
       
       public Fabricante (){}


}
