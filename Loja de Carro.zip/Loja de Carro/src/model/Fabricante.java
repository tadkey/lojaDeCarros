/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;
import java.util.ArrayList;
/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class Fabricante {
    private Integer id; private String marca; private String modelo;
    private ArrayList<Estoque> estoque = new ArrayList<Estoque>();

}
