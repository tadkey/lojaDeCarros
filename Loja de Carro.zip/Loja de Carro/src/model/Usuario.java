/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.util.ArrayList;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class Usuario {
    private Integer id; private String telefone;    private String cpf;
    private String nome;   private String email;    private String cargo;
    private Integer matricula;  private Login login;
    private ArrayList<Venda1> vendas = new ArrayList<Venda1>(); 

    public Usuario(Integer id, String telefone, String cpf, String nome, String email, String cargo, Integer matricula, Login login) {
        this.id = id;
        this.telefone = telefone;
        this.cpf = cpf;
        this.nome = nome;
        this.email = email;
        this.cargo = cargo;
        this.matricula = matricula;
        this.login = login;
    }
    
   

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public Integer getMatricula() {
        return matricula;
    }

    public void setMatricula(Integer matricula) {
        this.matricula = matricula;
    }

    public Login getLogin() {
        return login;
    }

    public void setLogin(Login login) {
        this.login = login;
    }



    public ArrayList<Venda1> getVendas() {
        return vendas;
    }

    public void setVendas(ArrayList<Venda1> vendas) {
        this.vendas = vendas;
    }
    
      public Usuario(){}

}
