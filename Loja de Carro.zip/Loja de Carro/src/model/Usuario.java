/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

import java.util.ArrayList;

/**
 *
 * @author Expression Tarcisio is undefined on line 12, column 14 in Templates/Classes/Class.java.
 */
public class Usuario {
    private Integer id; private String telefone;    private String cpf;
    private String nome;   private String email;    private String cargo;
    private Integer matricula;  private Login login;
    private ArrayList<Venda> vendas = new ArrayList<Venda>(); 

}
